export class Emp{
    public empno: number = 0;
    public empName: string = '';
    public job: string = '';
    public salary: number = 0;

    constructor(){

    }
    
}